#!/usr/bin/env python


from brain_games.games import even, game_frame


def main():
    print(game_frame.play_game(even))


if __name__ == '__main__':
    main()
