#!/usr/bin/env python


import brain_games.games.even


def main():
    print(brain_games.games.even.play_even())


if __name__ == '__main__':
    main()
